import 'package:flutter_sqllite/model.dart';
import 'package:path/path.dart';
import 'package:project/model.dart';


class Dbhelper {
  Database? _database;

  Future<Database?> get database async {
    if (_database != null) {
      return _database;
    } else {
      _database = await initDb();
      return _database;
    }
  }

  Future<Database> initDb() async {
    final dbpath = await getDatabasesPath();
    final note_db_path = join(dbpath, 'not.db');
    final db = await openDatabase(note_db_path, version: 1, onCreate: ((db, version) {
      db.execute(
        'CREATE TABLE notes(id INTEGER PRIMARY KEY, title TEXT, description TEXT)', // Update this line
      );
    }));
    return db;
  }

  insert(Note note) async {
    final db = await database;
    await db!.insert('notes',
        {'id': note.id, 'title': note.title, 'description': note.description},
        conflictAlgorithm: ConflictAlgorithm.replace);
  }

  update(Note note) async {
    final db = await database;
    await db!.update(
      'notes',
      {'id': note.id, 'title': note.title, 'description': note.description},
      where: "id = ?",
      whereArgs: [note.id],
    );
  }

  delete(int id) async {
    final db = await database;
    await db!.delete(
      'notes',
      where: "id = ?",
      whereArgs: [id],
    );
  }

  Future<List<Map<String, dynamic>>> queryAll() async {
    final db = await database;
    return db!.query('notes');
  }
}
