class Note {
  int id;
  String title;
  String description; // Fix the typo here

  var content;
  Note({
    required this.id,
    required this.title,
    required this.description,
  });
}